package pl.industrialconnect

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101820)
private val Panel = Color(0xFF1B2935)
private val Accent = Color(0xFF21A6A1)
private val Muted = Color(0xFF9DB0BE)

data class Device(
    val id: Int,
    val name: String,
    val kind: String,
    val address: String,
    val protocol: String,
    val online: Boolean,
    val value: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IndustrialConnectApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IndustrialConnectApp() {
    var devices by remember {
        mutableStateOf(
            listOf(
                Device(1, "PLC Demo", "Sterownik PLC", "192.168.1.10", "Symulator", true, "RUN"),
                Device(2, "Robot AMR Demo", "Robot mobilny", "BLE / Wi-Fi", "Symulator", true, "Gotowy"),
                Device(3, "Maszyna Demo", "Maszyna", "192.168.1.30", "Symulator", false, "STOP")
            )
        )
    }
    var selected by remember { mutableStateOf<Device?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showScan by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("Urządzenia") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Color(0xFFFFB454),
            background = Bg,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("INDUSTRIAL CONNECT", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("MOBILNY PANEL AUTOMATYKI", color = Muted, fontSize = 10.sp)
                        }
                    },
                    actions = {
                        Icon(Icons.Default.Settings, contentDescription = "Ustawienia",
                            modifier = Modifier.padding(end = 16.dp), tint = Muted)
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Urządzenia", "Diagnostyka", "Konto").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Urządzenia" -> Icons.Default.Devices
                                        "Diagnostyka" -> Icons.Default.MonitorHeart
                                        else -> Icons.Default.Person
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (tab == "Urządzenia") {
                    FloatingActionButton(
                        onClick = { showAdd = true },
                        containerColor = Accent,
                        contentColor = Color.White
                    ) { Icon(Icons.Default.Add, contentDescription = "Dodaj urządzenie") }
                }
            }
        ) { padding ->
            when (tab) {
                "Urządzenia" -> {
                    if (selected == null) {
                        DeviceList(
                            devices = devices,
                            padding = padding,
                            onSelect = { selected = it },
                            onScan = { showScan = true }
                        )
                    } else {
                        DeviceDetails(
                            device = selected!!,
                            onBack = { selected = null },
                            onToggle = {
                                val changed = selected!!.copy(
                                    value = if (selected!!.value == "RUN") "STOP" else "RUN"
                                )
                                devices = devices.map { if (it.id == changed.id) changed else it }
                                selected = changed
                            }
                        )
                    }
                }
                "Diagnostyka" -> DiagnosticScreen(padding)
                else -> AccountScreen(padding)
            }
        }

        if (showAdd) {
            AddDeviceDialog(
                onDismiss = { showAdd = false },
                onAdd = { name, kind, address, protocol ->
                    val newDevice = Device(
                        (devices.maxOfOrNull { it.id } ?: 0) + 1,
                        name, kind, address, protocol, false, "Niepołączony"
                    )
                    devices = devices + newDevice
                    showAdd = false
                }
            )
        }
        if (showScan) {
            AlertDialog(
                onDismissRequest = { showScan = false },
                title = { Text("Wyszukiwanie urządzeń") },
                text = {
                    Text(
                        "W tej wersji demonstracyjnej skanowanie jest makietą. " +
                        "W kolejnej iteracji dodamy wykrywanie usług i urządzeń w dozwolonej sieci lokalnej " +
                        "oraz skanowanie Bluetooth LE z wymaganymi uprawnieniami Androida."
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showScan = false }) { Text("Rozumiem") }
                }
            )
        }
    }
}

@Composable
fun DeviceList(
    devices: List<Device>,
    padding: PaddingValues,
    onSelect: (Device) -> Unit,
    onScan: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            Text("CENTRUM POŁĄCZEŃ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("Twoje urządzenia", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("Tryb DEMO • brak połączenia z rzeczywistą maszyną", color = Color(0xFFFFB454), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("URZĄDZENIA", devices.size.toString(), Modifier.weight(1f))
                SummaryCard("ONLINE", devices.count { it.online }.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onScan, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                Icon(Icons.Default.Search, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Wyszukaj urządzenia")
            }
            Text("LISTA URZĄDZEŃ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        items(devices) { device ->
            DeviceCard(device = device, onClick = { onSelect(device) })
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted, fontSize = 10.sp)
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun DeviceCard(device: Device, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                when {
                    device.kind.contains("Robot") -> Icons.Default.SmartToy
                    device.kind.contains("PLC") -> Icons.Default.Memory
                    else -> Icons.Default.Factory
                },
                contentDescription = null, tint = Accent, modifier = Modifier.size(30.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(device.name, fontWeight = FontWeight.Bold)
                Text("${device.kind} • ${device.address}", color = Muted, fontSize = 11.sp)
                Text("${device.protocol} • ${device.value}", color = Muted, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(if (device.online) "ONLINE" else "OFFLINE",
                    color = if (device.online) Color(0xFF57D69A) else Color(0xFFFFB454),
                    fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Muted)
            }
        }
    }
}

@Composable
fun DeviceDetails(device: Device, onBack: () -> Unit, onToggle: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text("Wróć") }
        Text(device.name, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("${device.kind} • ${device.protocol}", color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("STATUS URZĄDZENIA", color = Muted, fontSize = 11.sp)
                Text(device.value, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Adres: ${device.address}", color = Muted)
                Text("Tryb demonstracyjny. Wartości nie pochodzą z PLC.", color = Color(0xFFFFB454), fontSize = 12.sp)
            }
        }
        Text("STEROWANIE TESTOWE", fontWeight = FontWeight.Bold)
        Button(onClick = onToggle, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            Icon(Icons.Default.PowerSettingsNew, null)
            Spacer(Modifier.width(8.dp))
            Text(if (device.value == "RUN") "Zmień stan na STOP (DEMO)" else "Zmień stan na RUN (DEMO)")
        }
        Text("Rzeczywiste sterowanie będzie dostępne dopiero po konfiguracji protokołu, autoryzacji i blokad bezpieczeństwa.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun DiagnosticScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("DIAGNOSTYKA", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("Stan systemu", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Tryb aplikacji: DEMO", color = Color(0xFFFFB454))
                Text("Połączenia sprzętowe: nie skonfigurowano")
                Text("Dziennik zdarzeń: gotowy do rozbudowy")
                Text("Bezpieczeństwo: brak poleceń wysyłanych do maszyn")
            }
        }
    }
}

@Composable
fun AccountScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("KONTO I UPRAWNIENIA", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text("Profil operatora", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp)) {
                Text("Użytkownik: DEMO")
                Text("Rola: Operator testowy", color = Muted)
                Text("Logowanie i role produkcyjne będą wdrożone w kolejnej wersji.", color = Muted)
            }
        }
    }
}

@Composable
fun AddDeviceDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("Sterownik PLC") }
    var protocol by remember { mutableStateOf("OPC UA") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj urządzenie") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nazwa urządzenia") }, singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("Adres IP / identyfikator") }, singleLine = true)
                Text("Typ urządzenia")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Sterownik PLC", "Robot", "Maszyna").forEach {
                        FilterChip(selected = kind == it, onClick = { kind = it }, label = { Text(it) })
                    }
                }
                Text("Protokół")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("OPC UA", "Modbus TCP", "MQTT", "BLE").forEach {
                        FilterChip(selected = protocol == it, onClick = { protocol = it }, label = { Text(it) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && address.isNotBlank(),
                onClick = { onAdd(name.trim(), kind, address.trim(), protocol) }
            ) { Text("Dodaj") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Anuluj") } }
    )
}
