# Industrial Connect 1.0

Pierwszy szkielet aplikacji Android w Kotlin + Jetpack Compose.

## Co zawiera
- ciemny interfejs przemysłowy,
- przykładową listę PLC, robota mobilnego i maszyny,
- ręczne dodawanie urządzeń (lokalnie, demonstracyjnie),
- ekran wyszukiwania jako makietę,
- ekran szczegółów z przełączaniem stanu DEMO,
- zakładki diagnostyki i konta.

## Ważne ograniczenia
To jest prototyp interfejsu. Nie łączy się jeszcze z PLC, robotami ani urządzeniami Bluetooth/Wi-Fi.
Wszystkie urządzenia i wartości są przykładowe. Przyciski zmieniają wyłącznie stan lokalny w aplikacji.
Nie używać do sterowania rzeczywistą maszyną.

## Otwieranie w Android Studio
1. Rozpakuj archiwum.
2. W Android Studio wybierz **Open** i wskaż folder `IndustrialConnect`.
3. Poczekaj na synchronizację Gradle.
4. Uruchom aplikację na emulatorze lub telefonie z Androidem.

Wymagane: Android Studio z obsługą Android Gradle Plugin 8.7.3, JDK 17 oraz Android SDK 35.
Jeśli Android Studio zaproponuje aktualizację Gradle lub wtyczek, najpierw sprawdź zgodność wersji.

## Następny etap
- rzeczywiste skanowanie BLE z uprawnieniami runtime,
- konfiguracja sieci i ręczny test połączenia,
- adaptery protokołów OPC UA / Modbus TCP / MQTT,
- logowanie, role i dziennik audytowy,
- bezpieczne bramkowanie poleceń sterujących.
